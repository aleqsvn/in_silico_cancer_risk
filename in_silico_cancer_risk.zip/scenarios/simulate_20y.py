import pandas as pd
from model.risk_model import calculate_lifetime_risk, load_data

data = load_data("data/substances.csv")

def simulate(product="Сигаретах"):
    risks = []
    for _, row in data.iterrows():
        conc = row[f"Конц. в {product} (мкг/100 мл)"]
        iur = row["IUR ((мкг/м³)^-1)"]
        risk = calculate_lifetime_risk(conc, iur)
        risks.append((row["Вещество"], risk))
    return pd.DataFrame(risks, columns=["Вещество", "Риск"])

if __name__ == "__main__":
    df = simulate("Сигаретах")
    print(df.sort_values("Риск", ascending=False))
