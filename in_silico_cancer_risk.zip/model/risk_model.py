import pandas as pd

def calculate_lifetime_risk(concentration, iur, years=20, daily_volume_l=20):
    daily_exposure = (concentration * daily_volume_l) / 100  # мкг/сутки
    annual_exposure = daily_exposure * 365
    lifetime_exposure = annual_exposure * years
    lifetime_risk = lifetime_exposure * iur / 1_000_000  # приведение к мкг/м³
    return lifetime_risk

def load_data(path):
    return pd.read_csv(path)
