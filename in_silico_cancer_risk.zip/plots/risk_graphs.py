import matplotlib.pyplot as plt
from scenarios.simulate_20y import simulate

df = simulate("Сигаретах")

plt.figure(figsize=(10, 6))
plt.barh(df["Вещество"], df["Риск"])
plt.xlabel("Оценка пожизненного канцерогенного риска")
plt.title("Канцерогенный риск от веществ в сигаретах")
plt.tight_layout()
plt.show()
